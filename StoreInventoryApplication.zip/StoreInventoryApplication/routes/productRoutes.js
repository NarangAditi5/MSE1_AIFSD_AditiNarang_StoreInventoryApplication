const express = require('express');
const router = express.Router();
const {
    addProduct,
    getProducts,
    getProductById,
    updateProduct,
    deleteProduct,
    searchProducts,
    getProductsByCategory
} = require('../controllers/productController');

// Search and Category routes should come BEFORE /:id route
router.get('/search', searchProducts);
router.get('/category', getProductsByCategory);

router.route('/')
    .post(addProduct)
    .get(getProducts);

router.route('/:id')
    .get(getProductById)
    .put(updateProduct)
    .delete(deleteProduct);

module.exports = router;
