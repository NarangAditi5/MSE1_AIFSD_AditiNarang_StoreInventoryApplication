# Deployment Guide

## 1. MongoDB Atlas Setup
1. Log in to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
2. Create a new Project and Cluster.
3. In **Network Access**, add IP `0.0.0.0/0` (Allow access from anywhere).
4. In **Database Access**, create a user with a password.
5. Click **Connect** → **Drivers** → Copy the **Connection String**.
6. Replace `<username>` and `<password>` in the connection string.

## 2. Push to GitHub
1. Create a ` .gitignore` file:
```text
node_modules
.env
```
2. Initialize and push:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

## 3. Deploy on Render
1. Log in to [Render](https://render.com/).
2. Click **New** → **Web Service**.
3. Connect your GitHub repository.
4. Set **Build Command**: `npm install`
5. Set **Start Command**: `npm start`
6. In **Environment Variables**, add:
   - `MONGODB_URI`: (Your Atlas connection string)
   - `PORT`: `10000` (Render default)
   - `NODE_ENV`: `production`
7. Click **Deploy**.
