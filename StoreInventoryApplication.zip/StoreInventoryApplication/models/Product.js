const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    productName: {
        type: String,
        required: [true, 'Product Name is required'],
        trim: true
    },
    productCode: {
        type: String,
        required: [true, 'Product Code is required'],
        unique: true,
        trim: true
    },
    category: {
        type: String,
        required: [true, 'Category is required'],
        enum: ['Electronics', 'Clothing', 'Food', 'Furniture', 'Other']
    },
    supplierName: {
        type: String,
        required: [true, 'Supplier Name is required']
    },
    quantityInStock: {
        type: Number,
        required: [true, 'Quantity is required'],
        min: [0, 'Quantity cannot be negative']
    },
    reorderLevel: {
        type: Number,
        required: [true, 'Reorder level is required'],
        min: [1, 'Reorder level must be greater than 0']
    },
    unitPrice: {
        type: Number,
        required: [true, 'Unit price is required'],
        min: [0.01, 'Unit price must be positive']
    },
    manufactureDate: {
        type: Date,
        required: [true, 'Manufacture date is required']
    },
    productType: {
        type: String,
        required: [true, 'Product type is required'],
        enum: ['Perishable', 'Non-Perishable']
    },
    status: {
        type: String,
        default: 'Available',
        enum: ['Available', 'Out of Stock']
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
