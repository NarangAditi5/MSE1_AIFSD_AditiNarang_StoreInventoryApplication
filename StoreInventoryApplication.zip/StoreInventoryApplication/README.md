# 🛒 Store Inventory Management System (SIMS)

[![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)](https://nodejs.org/)
[![Express.js](https://img.shields.io/badge/Express.js-000000?style=for-the-badge&logo=express&logoColor=white)](https://expressjs.com/)
[![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)](https://www.mongodb.com/)
[![Mongoose](https://img.shields.io/badge/Mongoose-880000?style=for-the-badge&logo=mongoose&logoColor=white)](https://mongoosejs.com/)

A professional-grade **RESTful Inventory Management API** designed for high scalability and data integrity. Built for retail businesses to track stock levels, manage product lifecycles, and optimize reordering processes.

---

## 🏗️ System Architecture

The application follows the **MVC (Model-View-Controller)** pattern, ensuring a clean separation between data structure, business logic, and routing.

```mermaid
graph TD
    Client[Postman/Frontend] -->|HTTP Request| Server[Express Server]
    Server -->|Routes| Router[Routing Layer]
    Router -->|Controllers| Logic[Product Controller]
    Logic -->|Models| Mongoose[Mongoose ODM]
    Mongoose -->|Query| DB[(MongoDB Atlas)]
    DB -->|Data| Mongoose
    Mongoose -->|JSON| Logic
    Logic -->|Response| Client
```

---

## 🔄 Data Lifecycle Flow

This diagram illustrates how a "Create Product" request flows through our system:

```mermaid
sequenceDiagram
    participant U as User/Client
    participant R as Routes
    participant C as Controller
    participant M as Mongoose Model
    participant DB as MongoDB

    U->>R: POST /api/products (JSON Body)
    R->>C: Call addProduct()
    C->>M: Validate Request Data
    alt Data Valid
        M->>DB: Save Product Document
        DB-->>M: Success
        M-->>C: Product Object
        C-->>U: HTTP 201 (Created)
    else Data Invalid
        M-->>C: Validation Error
        C-->>U: HTTP 400 (Bad Request)
    end
```

---

## 🌟 Key Features

- **🛡️ Data Integrity**: Strict Mongoose schema validations (unique codes, positive pricing, enum constraints).
- **🔍 Advanced Search**: Case-insensitive partial name matching for quick product discovery.
- **🏷️ Smart Filtering**: Category-based segmentation (Electronics, Food, Clothing, etc.).
- **📉 Reorder Intelligence**: Built-in reorder level tracking for proactive stock management.
- **⚠️ Global Error Handler**: Centralized middleware to catch and standardize all API errors.

---

## 📁 Repository Structure

```text
StoreInventoryApplication/
├── config/             # DB configuration & environment setup
│   └── db.js           # Production-ready MongoDB connection
├── controllers/        # Business logic & Database interaction
│   └── productController.js 
├── middleware/         # Custom request interceptors
│   └── errorMiddleware.js # Centralized Error Handling
├── models/             # Schema definitions (Source of Truth)
│   └── Product.js      # Robust Product Schema
├── routes/             # API Endpoint Mapping
│   └── productRoutes.js
├── .env                # Secure Environment Variables
├── server.js           # App Bootstrapper
└── package.json        # Manifest & Scripts
```

---

## 🛠️ Installation & Setup

### 1. Prerequisites
- **Node.js** (v14+)
- **MongoDB Atlas** Account

### 2. Quick Start
```bash
# Clone the repository
git clone <your-repo-url>

# Install Production & Dev Dependencies
npm install

# Setup Environment
touch .env
```

### 3. Configure `.env`
```env
PORT=5000
MONGODB_URI=mongodb+srv://<user>:<password>@cluster.mongodb.net/storeDB
NODE_ENV=development
```

### 4. Run the Engine
```bash
# Development (with auto-reload)
npm run dev

# Production
npm start
```

---

## 🛣️ API Documentation (RESTful)

| Action | Method | Endpoint | Description | Status Code |
| :--- | :--- | :--- | :--- | :--- |
| **Add Product** | `POST` | `/api/products` | Create a new product entry | `210 Created` |
| **Fetch All** | `GET` | `/api/products` | List all inventory items | `200 OK` |
| **Get Details** | `GET` | `/api/products/:id` | Fetch specific product by ID | `200 OK / 404` |
| **Update** | `PUT` | `/api/products/:id` | Modify product attributes | `200 OK` |
| **Delete** | `DELETE` | `/api/products/:id` | Permanently remove item | `200 OK` |
| **Search** | `GET` | `/api/products/search?name=...` | Regex-based name search | `200 OK` |
| **Filter** | `GET` | `/api/products/category?cat=...` | Category specific view | `200 OK` |

---

## 🎓 Best Practices Implemented

- **Centralized Error Handling**: No more messy `try/catch` in every route; handled globally for consistency.
- **REST Semantic Status Codes**: Uses appropriate `201`, `400`, `404`, and `500` codes.
- **Environment Safety**: Uses `dotenv` to keep sensitive DB credentials out of version control.
- **Modular Codebase**: Separation of concerns makes the code easy to unit test and scale.
- **CORS Enabled**: Cross-Origin Resource Sharing configured for frontend integration.

---

## 🧪 Testing Bench (Postman)

**POST Body Example:**
```json
{
    "productName": "Ergonomic Gaming Chair",
    "productCode": "FUR-CH-001",
    "category": "Furniture",
    "supplierName": "EliteComfort",
    "quantityInStock": 25,
    "reorderLevel": 5,
    "unitPrice": 199.99,
    "manufactureDate": "2026-02-10",
    "productType": "Non-Perishable"
}
```

---

Developed with ❤️ for Academic Excellence.
