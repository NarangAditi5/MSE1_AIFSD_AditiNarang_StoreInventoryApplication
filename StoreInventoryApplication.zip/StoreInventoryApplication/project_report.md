# Project Report: Store Inventory Management Backend API

## 1. Introduction
The Store Inventory Management System is a backend REST API designed for retail businesses to manage their product stock efficiently. It provides endpoints for adding, viewing, updating, and deleting products, as well as searching and filtering options.

## 2. Technology Stack
- **Runtime:** Node.js
- **Framework:** Express.js
- **Database:** MongoDB Atlas (NoSQL)
- **ODM:** Mongoose
- **Environment Management:** dotenv
- **Middleware:** CORS, Express JSON parser
- **Tools:** Postman (Testing), GitHub (Version Control), Render (Deployment)

## 3. System Architecture
The project follows the **MVC (Model-View-Controller)** pattern for clean separation of concerns:
- **Models:** Define the data schema and validations.
- **Controllers:** Contain the business logic and handle requests.
- **Routes:** Map URL endpoints to controller functions.
- **Middleware:** Centralized error handling and security headers.

## 4. Folder Structure
```text
backend
│
├── config
│   └── db.js (MongoDB Connection)
├── controllers
│   └── productController.js (Business Logic)
├── middleware
│   └── errorMiddleware.js (Global Error Handler)
├── models
│   └── Product.js (Mongoose Schema)
├── routes
│   └── productRoutes.js (Endpoint Definitions)
├── .env (Environment Variables)
├── server.js (Application Entry Point)
└── package.json (Dependencies and Scripts)
```

## 5. Key Features & Validations
- **Unique Product Code:** Prevents duplicate stock entries.
- **Auto-generated IDs:** Handled by MongoDB.
- **Data Validation:** Prevents negative stock and ensures data integrity.
- **Centralized Error Handling:** Consistent API responses for errors.

## 6. Screenshots Placeholders
- [Placeholder: Postman API Testing Console]
- [Placeholder: MongoDB Atlas Collection View]
- [Placeholder: Render Deployment Dashboard]
- [Placeholder: GitHub Repository Overview]

## 7. Conclusion
The API successfully implements all required CRUD operations and search-filter functionalities, providing a solid foundation for any retail inventory management application.
