# API Testing Guide (Postman)

Base URL: `http://localhost:5000/api/products`

## 1. Add New Product
- **Method:** `POST`
- **URL:** `/`
- **Body (JSON):**
```json
{
    "productName": "Wireless Mouse",
    "productCode": "WM-001",
    "category": "Electronics",
    "supplierName": "TechLogistics",
    "quantityInStock": 50,
    "reorderLevel": 10,
    "unitPrice": 25.99,
    "manufactureDate": "2026-01-15",
    "productType": "Non-Perishable",
    "status": "Available"
}
```

## 2. Get All Products
- **Method:** `GET`
- **URL:** `/`

## 3. Get Product by ID
- **Method:** `GET`
- **URL:** `/:id` (Replace `:id` with actual MongoDB ID)

## 4. Update Product
- **Method:** `PUT`
- **URL:** `/:id`
- **Body (JSON):**
```json
{
    "quantityInStock": 45,
    "status": "Available"
}
```

## 5. Search by Name
- **Method:** `GET`
- **URL:** `/search?name=Wireless`

## 6. Filter by Category
- **Method:** `GET`
- **URL:** `/category?cat=Electronics`

## 7. Delete Product
- **Method:** `DELETE`
- **URL:** `/:id`
