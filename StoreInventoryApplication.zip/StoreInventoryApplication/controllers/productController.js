const Product = require('../models/Product');


// @desc    Add a new product
// @route   POST /api/products
// @access  Public
const addProduct = async (req, res, next) => {
    try {
        const product = await Product.create(req.body);
        res.status(201).json(product);
    } catch (error) {
        res.status(400);
        next(error);
    }
};

// @desc    Get all products
// @route   GET /api/products
// @access  Public
const getProducts = async (req, res, next) => {
    try {
        const products = await Product.find({});
        res.status(200).json(products);
    } catch (error) {
        res.status(500);
        next(error);
    }
};

// @desc    Get product by ID
// @route   GET /api/products/:id
// @access  Public
const getProductById = async (req, res, next) => {
    try {
        const product = await Product.findById(req.params.id);
        if (product) {
            res.status(200).json(product);
        } else {
            res.status(404);
            throw new Error('Product not found');
        }
    } catch (error) {
        next(error);
    }
};

// @desc    Update product
// @route   PUT /api/products/:id
// @access  Public
const updateProduct = async (req, res, next) => {
    try {
        const product = await Product.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
        if (product) {
            res.status(200).json(product);
        } else {
            res.status(404);
            throw new Error('Product not found');
        }
    } catch (error) {
        res.status(400);
        next(error);
    }
};

// @desc    Delete product
// @route   DELETE /api/products/:id
// @access  Public
const deleteProduct = async (req, res, next) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        if (product) {
            res.status(200).json({ message: 'Product removed' });
        } else {
            res.status(404);
            throw new Error('Product not found');
        }
    } catch (error) {
        next(error);
    }
};

// @desc    Search products by name
// @route   GET /api/products/search
// @access  Public
const searchProducts = async (req, res, next) => {
    try {
        const { name } = req.query;
        const products = await Product.find({
            productName: { $regex: name, $options: 'i' }
        });
        res.status(200).json(products);
    } catch (error) {
        res.status(500);
        next(error);
    }
};

// @desc    Filter products by category
// @route   GET /api/products/category
// @access  Public
const getProductsByCategory = async (req, res, next) => {
    try {
        const { cat } = req.query;
        const products = await Product.find({ category: cat });
        res.status(200).json(products);
    } catch (error) {
        res.status(500);
        next(error);
    }
};

module.exports = {
    addProduct,
    getProducts,
    getProductById,
    updateProduct,
    deleteProduct,
    searchProducts,
    getProductsByCategory
};
